#!/bin/bash

chown -R www-data /json

docker-php-entrypoint php-fpm