<?php


echo "Hello, World!" . $_GET['name'] ?? "";
