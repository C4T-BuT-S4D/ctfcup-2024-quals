import Vapor

struct AddGroup: Codable {
    var user: String
    var chat: String
}
