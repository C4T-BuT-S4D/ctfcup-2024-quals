import Vapor

struct CreateGroup: Codable {
    var name: String
}
